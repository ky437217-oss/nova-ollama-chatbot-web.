const { spawn } = require("node:child_process");
const path = require("node:path");
const assert = require("node:assert/strict");
const port = 43000 + Math.floor(Math.random()*1000);
const child = spawn(process.execPath,[path.join(__dirname,"..","server.js")],{env:{...process.env,PORT:String(port),OLLAMA_HOST:"http://127.0.0.1:1"},stdio:"ignore"});
const base=`http://127.0.0.1:${port}`;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 try {
  let ready=false;
  for(let i=0;i<40;i++){try{const r=await fetch(base+"/");if(r.ok){ready=true;break;}}catch{}await sleep(100);}
  assert.equal(ready,true,"server did not start");
  const home=await fetch(base+"/");assert.equal(home.status,200);assert.match(await home.text(),/Nova — All-Rounder AI/);
  const health=await fetch(base+"/api/health");assert.equal(health.status,200);const h=await health.json();assert.equal(h.ok,true);assert.equal(h.ollamaConnected,false);
  const bad=await fetch(base+"/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"",messages:[]})});assert.equal(bad.status,400);
  const missing=await fetch(base+"/not-a-file");assert.equal(missing.status,404);
  console.log("PASS: homepage, health route, invalid chat validation, 404 route");
 } catch(e){console.error("FAIL:",e);process.exitCode=1;}
 finally{child.kill();}
})();
