# Nova — All-Rounder Ollama Chatbot (starter)

A standalone, dependency-free Windows-friendly web app for local Ollama chat. This package does not install software or change any existing project.

## Included
- Dark responsive chat interface and local Ollama model selector
- Multi-turn chat history in browser `localStorage`
- Coding, document/file-context, vision, voice and plan-only agent modes
- Text/code attachments and PNG/JPEG/WebP image input to vision-capable Ollama models
- Optional user-authored memory stored in browser `localStorage`
- Browser speech recognition when supported and text-to-speech in Voice mode
- Loopback-only Node server, request-size limits, input validation and security headers

## Important boundaries
- Agent Planner is proposal-only. It does not run shell commands, modify local files, control the desktop, or automate a browser.
- File contents are sent to the selected Ollama model only when you submit a message. Text is limited to 120,000 characters per attachment; file size is limited to 5 MB.
- PDF parsing, OCR, retrieval-augmented generation, cloud APIs, login, and server-side conversation storage are not included.
- Browser speech recognition availability and its privacy behavior vary by browser/OS; speech-to-text may use browser-managed services. Text-to-speech is browser-native.
- Browser local storage is not encrypted. Do not put secrets, passwords, API keys, or sensitive documents in memory/history.
- Ollama is expected at `http://127.0.0.1:11434`. The app binds only to `127.0.0.1:4173`.

## Requirements
- Node.js 18+ (uses built-in `fetch`); no npm dependencies
- Ollama for local model inference

## Run on Windows 11
1. Extract the ZIP to a **new folder** such as `C:\Users\ASUS\Desktop\AllRounder-Ollama-Chatbot`. Do not extract over an existing folder.
2. Open PowerShell in that folder.
3. Run these checks first:

```powershell
node --version
ollama --version
Test-NetConnection 127.0.0.1 -Port 11434
ollama list
```

4. Start the app:

```powershell
node .\server.js
```

5. Open `http://127.0.0.1:4173` in your browser. Stop the app with `Ctrl+C`.

If port 4173 is busy, use `$env:PORT=4174; node .\server.js` and visit `http://127.0.0.1:4174`.

## Optional vision model
Use an image-capable model already installed in Ollama. To add a model, first check available disk space and the model's requirements; pulling a model downloads data and uses disk space, so do not run a pull without choosing to do so. Official model library: https://ollama.com/library

## Read-only preflight checks
These commands only inspect; they do not install, delete, or modify anything:

```powershell
Write-Host "=== Existing destination ==="
Test-Path "$HOME\Desktop\AllRounder-Ollama-Chatbot"
Write-Host "=== Node ==="
node --version
Write-Host "=== Ollama CLI ==="
ollama --version
Write-Host "=== Ollama endpoint ==="
try { (Invoke-RestMethod http://127.0.0.1:11434/api/tags).models | Select-Object name, size } catch { Write-Host "Ollama API unavailable: $($_.Exception.Message)" }
Write-Host "=== Port 4173 ==="
Get-NetTCPConnection -LocalPort 4173 -State Listen -ErrorAction SilentlyContinue | Select-Object LocalAddress, LocalPort, OwningProcess
```

If the destination already exists, stop and inspect its contents before extracting. Do not overwrite it.

## Tests
Run the included smoke tests:

```powershell
node .\tests\smoke-test.js
```

The smoke test starts the server on a temporary local port, checks the home page and health route, and validates request rejection. A passing smoke test does not prove Ollama inference or browser microphone/image capabilities work; test those in the UI.

## Troubleshooting
- `Ollama disconnected`: start the Ollama desktop app and click Refresh.
- `No local models found`: check `ollama list`; choose a model you already have.
- Image requests fail: selected model must support image input.
- Browser mic unavailable: try a supported browser and grant microphone permission; typing still works.
