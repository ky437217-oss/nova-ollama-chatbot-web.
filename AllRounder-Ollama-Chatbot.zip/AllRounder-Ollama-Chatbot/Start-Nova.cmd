@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install it only after reviewing the README.
  pause
  exit /b 1
)
node server.js
pause
