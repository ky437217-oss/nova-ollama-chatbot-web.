const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

const ROOT = __dirname;
const HOST = "127.0.0.1";
const PORT = Number(process.env.PORT || 4173);
const OLLAMA = (process.env.OLLAMA_HOST || "http://127.0.0.1:11434").replace(/\/+$/, "");
const MAX_BODY = 12 * 1024 * 1024;
const MIME = {".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8",".json":"application/json; charset=utf-8",".svg":"image/svg+xml"};

function send(res, status, data, type="application/json; charset=utf-8") {
  res.writeHead(status, {"Content-Type":type,"X-Content-Type-Options":"nosniff","Cache-Control":"no-store","Content-Security-Policy":"default-src 'self' data: blob:; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self' http://127.0.0.1:11434 http://localhost:11434; media-src 'self' blob:; base-uri 'none'; frame-ancestors 'none'","Referrer-Policy":"no-referrer"});
  res.end(Buffer.isBuffer(data) ? data : (typeof data === "string" ? data : JSON.stringify(data)));
}
function readBody(req) {
  return new Promise((resolve,reject)=>{
    let size=0, chunks=[];
    req.on("data", c=>{ size+=c.length; if(size>MAX_BODY){ reject(new Error("Request too large (12 MB limit).")); req.destroy(); } else chunks.push(c); });
    req.on("end",()=>{ try { resolve(JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}")); } catch { reject(new Error("Invalid JSON body.")); } });
    req.on("error",reject);
  });
}
async function ollama(pathname, payload) {
  const controller = new AbortController();
  const timer = setTimeout(()=>controller.abort(), 300000);
  try {
    const r = await fetch(OLLAMA + pathname, {
      method: payload ? "POST" : "GET",
      headers: payload ? {"Content-Type":"application/json"} : {},
      body: payload ? JSON.stringify(payload) : undefined,
      signal: controller.signal
    });
    const body = await r.text();
    if(!r.ok) throw new Error(`Ollama returned HTTP ${r.status}: ${body.slice(0,500)}`);
    try { return JSON.parse(body); } catch { throw new Error("Ollama returned an unexpected response."); }
  } finally { clearTimeout(timer); }
}
function safeFile(urlPath) {
  const decoded = decodeURIComponent(urlPath.split("?")[0]);
  const requested = decoded === "/" ? "/index.html" : decoded;
  const resolved = path.resolve(ROOT, "." + requested);
  if (!resolved.startsWith(ROOT + path.sep) && resolved !== ROOT) return null;
  return resolved;
}
const server = http.createServer(async (req,res)=>{
  const url = new URL(req.url, `http://${HOST}:${PORT}`);
  try {
    if(req.method==="GET" && url.pathname==="/api/health") {
      let connected=false, models=[];
      try { const result=await ollama("/api/tags"); models=(result.models||[]).map(m=>m.name); connected=true; } catch {}
      return send(res,200,{ok:true,app:"All-Rounder Ollama Chatbot",ollamaConnected:connected,models,ollamaHost:OLLAMA});
    }
    if(req.method==="GET" && url.pathname==="/api/models") {
      const result=await ollama("/api/tags");
      return send(res,200,{models:(result.models||[]).map(m=>({name:m.name,size:m.size,modified_at:m.modified_at}))});
    }
    if(req.method==="POST" && url.pathname==="/api/chat") {
      const body=await readBody(req);
      if(typeof body.model!=="string" || !/^[\w./:-]{1,160}$/.test(body.model)) return send(res,400,{error:"Choose a valid model name."});
      if(!Array.isArray(body.messages) || body.messages.length<1 || body.messages.length>60) return send(res,400,{error:"messages must contain 1–60 items."});
      const messages=body.messages.map(m=>{
        if(!m || !["system","user","assistant"].includes(m.role) || typeof m.content!=="string") throw new Error("Invalid message format.");
        const item={role:m.role,content:m.content.slice(0,100000)};
        if(m.images!==undefined) {
          if(!Array.isArray(m.images) || m.images.length>2 || m.images.some(i=>typeof i!=="string" || i.length>8_000_000)) throw new Error("Invalid image payload.");
          item.images=m.images;
        }
        return item;
      });
      const result=await ollama("/api/chat",{model:body.model,messages,stream:false,options:{temperature:0.7}});
      return send(res,200,{message:result.message,done:result.done,model:result.model});
    }
    if(req.method==="GET") {
      const file=safeFile(url.pathname);
      if(!file || !fs.existsSync(file) || !fs.statSync(file).isFile()) return send(res,404,"Not found","text/plain; charset=utf-8");
      return send(res,200,fs.readFileSync(file),MIME[path.extname(file)]||"application/octet-stream");
    }
    return send(res,405,{error:"Method not allowed."});
  } catch(e) {
    const msg=e.name==="AbortError" ? "Ollama request timed out after 5 minutes." : (e.message||"Unexpected server error.");
    return send(res,500,{error:msg});
  }
});
server.listen(PORT,HOST,()=>console.log(`All-Rounder chatbot: http://${HOST}:${PORT}\nOllama API: ${OLLAMA}\nOnly listening on loopback; press Ctrl+C to stop.`));
